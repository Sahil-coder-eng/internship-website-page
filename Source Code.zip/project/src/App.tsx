import React from 'react';
import { Calendar, FileText, Mail, User, Download, ExternalLink, Award, BookOpen } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative max-w-7xl mx-auto px-6 py-16">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-white bg-opacity-20 rounded-full mb-6">
              <Award className="w-8 h-8" />
            </div>
            <h1 className="text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-blue-100">
              Assignment Submission
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              A comprehensive academic project demonstrating research, analysis, and innovative solutions
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <button 
                onClick={() => window.open('https://example.com/document', '_blank')}
                className="bg-white text-indigo-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transform hover:scale-105 transition-all duration-200 shadow-lg flex items-center gap-2"
              >
                <Download className="w-5 h-5" />
                Download PDF
              </button>
              <button 
                onClick={() => window.open('https://example.com/preview', '_blank')}
                className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-indigo-600 transform hover:scale-105 transition-all duration-200 flex items-center gap-2"
              >
                <ExternalLink className="w-5 h-5" />
                Live Preview
              </button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-indigo-50 to-transparent"></div>
      </div>

      {/* Student Information Card */}
      <div className="max-w-7xl mx-auto px-6 -mt-8 relative z-10">
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 mb-12">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Student Information</h3>
                  <p className="text-gray-600">Academic Submission Details</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <Mail className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-sm text-gray-600">Email Address</p>
                    <p className="font-medium text-gray-800">samalsahil993@gmail.com</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <FileText className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-sm text-gray-600">Student ID</p>
                    <p className="font-medium text-gray-800">32287813</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <Calendar className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-sm text-gray-600">Submission Date</p>
                    <p className="font-medium text-gray-800">February 17, 2025</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Assignment Details</h3>
                  <p className="text-gray-600">Project Overview & Specifications</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
                  <h4 className="font-semibold text-gray-800 mb-2">Assignment Type</h4>
                  <p className="text-gray-600">Research & Development Project</p>
                </div>
                
                <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-100">
                  <h4 className="font-semibold text-gray-800 mb-2">Status</h4>
                  <p className="text-green-700 font-medium">✓ Completed & Submitted</p>
                </div>
                
                <div className="p-4 bg-gradient-to-r from-purple-50 to-violet-50 rounded-lg border border-purple-100">
                  <h4 className="font-semibold text-gray-800 mb-2">File Format</h4>
                  <p className="text-gray-600">PDF Document (Assignment 2_32287813.pdf)</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Assignment Content Preview */}
      <div className="max-w-7xl mx-auto px-6 mb-12">
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
          <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 border-b border-gray-200">
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Assignment Content</h2>
            <p className="text-gray-600">Comprehensive academic research and analysis</p>
          </div>
          
          <div className="p-8">
            <div className="grid md:grid-cols-3 gap-8 mb-8">
              <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-100">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-800 mb-2">Research Paper</h3>
                <p className="text-gray-600 text-sm">In-depth analysis and findings</p>
              </div>
              
              <div className="text-center p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border border-green-100">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-800 mb-2">Academic Excellence</h3>
                <p className="text-gray-600 text-sm">High-quality academic standards</p>
              </div>
              
              <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-violet-50 rounded-xl border border-purple-100">
                <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-800 mb-2">Methodology</h3>
                <p className="text-gray-600 text-sm">Structured approach and process</p>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl p-6 mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Abstract</h3>
              <p className="text-gray-700 leading-relaxed mb-4">
                This assignment represents a comprehensive academic investigation into contemporary research methodologies 
                and their practical applications. The work demonstrates advanced analytical skills, critical thinking, 
                and the ability to synthesize complex information into coherent conclusions.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Through rigorous research and analysis, this project contributes valuable insights to the field of study 
                while maintaining the highest academic standards and ethical considerations.
              </p>
            </div>
            
            <div className="flex flex-wrap gap-4 justify-center">
              <button 
                onClick={() => window.open('mailto:samalsahil993@gmail.com', '_blank')}
                className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white px-6 py-3 rounded-lg font-semibold hover:from-indigo-600 hover:to-purple-600 transform hover:scale-105 transition-all duration-200 shadow-lg flex items-center gap-2"
              >
                <Mail className="w-5 h-5" />
                Contact Student
              </button>
              
              <button 
                onClick={() => window.open('https://example.com/references', '_blank')}
                className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-3 rounded-lg font-semibold hover:from-green-600 hover:to-emerald-600 transform hover:scale-105 transition-all duration-200 shadow-lg flex items-center gap-2"
              >
                <BookOpen className="w-5 h-5" />
                View References
              </button>
              
              <button 
                onClick={() => window.open('https://example.com/appendix', '_blank')}
                className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-3 rounded-lg font-semibold hover:from-orange-600 hover:to-red-600 transform hover:scale-105 transition-all duration-200 shadow-lg flex items-center gap-2"
              >
                <FileText className="w-5 h-5" />
                Appendix
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="max-w-7xl mx-auto px-6 pb-12">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl shadow-xl text-white p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4">Quick Actions</h2>
            <p className="text-blue-100 text-lg">Access additional resources and tools</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-4">
            <button 
              onClick={() => window.open('https://example.com/grades', '_blank')}
              className="bg-white bg-opacity-20 hover:bg-opacity-30 p-4 rounded-xl transition-all duration-200 transform hover:scale-105"
            >
              <Award className="w-8 h-8 mx-auto mb-2" />
              <p className="font-semibold">View Grades</p>
            </button>
            
            <button 
              onClick={() => window.open('https://example.com/feedback', '_blank')}
              className="bg-white bg-opacity-20 hover:bg-opacity-30 p-4 rounded-xl transition-all duration-200 transform hover:scale-105"
            >
              <FileText className="w-8 h-8 mx-auto mb-2" />
              <p className="font-semibold">Feedback</p>
            </button>
            
            <button 
              onClick={() => window.open('https://example.com/submissions', '_blank')}
              className="bg-white bg-opacity-20 hover:bg-opacity-30 p-4 rounded-xl transition-all duration-200 transform hover:scale-105"
            >
              <Calendar className="w-8 h-8 mx-auto mb-2" />
              <p className="font-semibold">All Submissions</p>
            </button>
            
            <button 
              onClick={() => window.open('https://example.com/resources', '_blank')}
              className="bg-white bg-opacity-20 hover:bg-opacity-30 p-4 rounded-xl transition-all duration-200 transform hover:scale-105"
            >
              <BookOpen className="w-8 h-8 mx-auto mb-2" />
              <p className="font-semibold">Resources</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;